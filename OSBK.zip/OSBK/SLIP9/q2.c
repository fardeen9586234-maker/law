#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX 256

// Function to implement 'search' command
void search_command(char *option, char *filename, char *pattern) {
    FILE *fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Error: Cannot open file %s\n", filename);
        return;
    }

    char line[MAX];
    int line_no = 0;
    int first_found = 0;

    while (fgets(line, sizeof(line), fp) != NULL) {
        line_no++;
        char *pos = line;

        while ((pos = strstr(pos, pattern)) != NULL) {
            if (strcmp(option, "f") == 0 && !first_found) {
                printf("First occurrence in Line %d: %s", line_no, line);
                first_found = 1;
                break;  // stop after first occurrence
            }
            if (strcmp(option, "a") == 0) {
                printf("Line %d: %s", line_no, line);
                pos += strlen(pattern); // move past current match
            } else {
                break;
            }
        }

        if (first_found && strcmp(option, "f") == 0)
            break;
    }

    fclose(fp);
}

int main() {
    char input[MAX], *args[10];
    int i;
    pid_t pid;

    while (1) {
        printf("myshell$ ");
        fflush(stdout);

        if (fgets(input, sizeof(input), stdin) == NULL)
            break;

        input[strcspn(input, "\n")] = '\0';  // remove newline

        if (strlen(input) == 0)
            continue;

        // Exit command
        if (strcmp(input, "exit") == 0)
            break;

        // Tokenize input
        i = 0;
        args[i] = strtok(input, " ");
        while (args[i] != NULL)
            args[++i] = strtok(NULL, " ");

        // Handle 'search' command
        if (args[0] && strcmp(args[0], "search") == 0) {
            if (args[1] && args[2] && args[3])
                search_command(args[1], args[2], args[3]);
            else
                printf("Usage: search [f|a] filename pattern\n");
            continue;
        }

        // Fork to execute other commands
        pid = fork();
        if (pid < 0) {
            printf("Error: Fork failed\n");
        } else if (pid == 0) {
            if (execvp(args[0], args) == -1)
                printf("Command not found: %s\n", args[0]);
            exit(0);
        } else {
            wait(NULL);  // Parent waits
        }
    }

    return 0;
}
