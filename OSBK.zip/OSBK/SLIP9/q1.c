#include <stdio.h>
#define MAX 20

int main() {
    int n_frames, i, j;
    int frames[MAX];
    int front = 0;  // Points to the oldest page (FIFO)
    int ref_string[MAX] = {8,5,7,8,5,7,2,3,7,3,5,9,4,6,2};
    int ref_len = 15;
    int page_faults = 0;

    printf("Enter number of frames: ");
    scanf("%d", &n_frames);

    // Initialize frames to -1 (empty)
    for (i = 0; i < n_frames; i++)
        frames[i] = -1;

    printf("\nReference String:\n");
    for (i = 0; i < ref_len; i++)
        printf("%d ", ref_string[i]);
    printf("\n\nPage Replacement Process (FIFO):\n");

    for (i = 0; i < ref_len; i++) {
        int current_page = ref_string[i];
        int found = 0;

        // Check if page is already in frame
        for (j = 0; j < n_frames; j++) {
            if (frames[j] == current_page) {
                found = 1; // Page hit
                break;
            }
        }

        // Page fault occurs
        if (!found) {
            frames[front] = current_page;       // Replace the oldest page
            front = (front + 1) % n_frames;    // Move front to next
            page_faults++;
        }

        // Print frame status
        printf("After page %2d: ", current_page);
        for (j = 0; j < n_frames; j++) {
            if (frames[j] != -1)
                printf("%2d ", frames[j]);
            else
                printf("-- ");
        }
        printf("\n");
    }

    printf("\nTotal Page Faults = %d\n", page_faults);

    return 0;
}
