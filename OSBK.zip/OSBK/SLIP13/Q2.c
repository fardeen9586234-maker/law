#include <iostream>
#include <vector>
#include <queue>
#include <numeric>
#include <iomanip>

using namespace std;

struct Process {
    int id;
    int arrival_time;
    int burst_time;
    int remaining_burst_time;
    int completion_time;
    int turnaround_time;
    int waiting_time;
};

bool compareArrival(const Process& a, const Process& b) {
    return a.arrival_time < b.arrival_time;
}

int main() {
    int num_processes, quantum;

    cout << "Enter number of processes: ";
    cin >> num_processes;
    cout << "Enter time quantum: ";
    cin >> quantum;

    vector<Process> processes(num_processes);
    cout << "Enter arrival time and burst time for each process:" << endl;
    for (int i = 0; i < num_processes; ++i) {
        processes[i].id = i + 1;
        cout << "Process " << processes[i].id << " Arrival Time: ";
        cin >> processes[i].arrival_time;
        cout << "Process " << processes[i].id << " Burst Time: ";
        cin >> processes[i].burst_time;
        processes[i].remaining_burst_time = processes[i].burst_time;
    }

    sort(processes.begin(), processes.end(), compareArrival);

    queue<int> ready_queue;
    vector<bool> in_queue(num_processes, false);
    int current_time = 0;
    int completed_processes = 0;
    int process_idx = 0;

    cout << "\n---------------------Gantt Chart---------------------" << endl;
    cout << "0";

    while (completed_processes < num_processes) {
        // Add new processes to the ready queue
        while (process_idx < num_processes && processes[process_idx].arrival_time <= current_time) {
            if (!in_queue[process_idx]) {
                ready_queue.push(process_idx);
                in_queue[process_idx] = true;
            }
            process_idx++;
        }

        if (ready_queue.empty()) {
            // If the ready queue is empty, increment time
            if (process_idx < num_processes) {
                current_time = processes[process_idx].arrival_time;
                continue;
            } else {
                break;
            }
        }

        int current_proc_idx = ready_queue.front();
        ready_queue.pop();

        int time_slice = min(quantum, processes[current_proc_idx].remaining_burst_time);

        current_time += time_slice;
        processes[current_proc_idx].remaining_burst_time -= time_slice;

        cout << " | P" << processes[current_proc_idx].id << " | " << current_time;

        // Add newly arrived processes to the queue
        while (process_idx < num_processes && processes[process_idx].arrival_time <= current_time) {
            if (!in_queue[process_idx]) {
                ready_queue.push(process_idx);
                in_queue[process_idx] = true;
            }
            process_idx++;
        }

        if (processes[current_proc_idx].remaining_burst_time > 0) {
            ready_queue.push(current_proc_idx);
        } else {
            processes[current_proc_idx].completion_time = current_time;
            completed_processes++;
        }
    }

    cout << "\n-----------------------------------------------------" << endl;

    double total_turnaround_time = 0;
    double total_waiting_time = 0;

    cout << "\nResults:" << endl;
    cout << "Process\tArrival\tBurst\tCompletion\tTurnaround\tWaiting" << endl;
    for (int i = 0; i < num_processes; ++i) {
        processes[i].turnaround_time = processes[i].completion_time - processes[i].arrival_time;
        processes[i].waiting_time = processes[i].turnaround_time - processes[i].burst_time;

        total_turnaround_time += processes[i].turnaround_time;
        total_waiting_time += processes[i].waiting_time;

        cout << processes[i].id << "\t" << processes[i].arrival_time << "\t" << processes[i].burst_time << "\t"
             << processes[i].completion_time << "\t\t" << processes[i].turnaround_time << "\t\t"
             << processes[i].waiting_time << endl;
    }

    cout << fixed << setprecision(2);
    cout << "\nAverage Turnaround Time: " << total_turnaround_time / num_processes << endl;
    cout << "Average Waiting Time: " << total_waiting_time / num_processes << endl;

    return 0;
}